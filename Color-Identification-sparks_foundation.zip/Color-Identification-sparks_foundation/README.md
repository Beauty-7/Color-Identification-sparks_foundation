# Sparks_foundation
IOT and Computer Vision -
Task 2 Color Identification
